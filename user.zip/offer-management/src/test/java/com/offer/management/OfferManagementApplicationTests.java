package com.offer.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfferManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
